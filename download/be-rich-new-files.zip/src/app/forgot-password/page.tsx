'use client';

import { useState } from 'react';

const LOGO_URL = 'https://z-cdn-media.chatglm.cn/files/1153c12e-46c2-4ff4-9bfb-9ee1ea9ad677.png?auth_key=1875725907-dba9b296a2b347a582e281f8c13d5dd1-0-abc6e2dfe8db025886d8c5cccb41f197';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (data.success) {
        setSent(true);
      } else {
        setError(data.error || 'Une erreur est survenue');
      }
    } catch {
      setError('Erreur réseau. Veuillez réessayer.');
    }

    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#0B1120] flex flex-col items-center justify-center px-5">
      {/* Decorative orbs */}
      <div className="fixed w-[200px] h-[200px] rounded-full bg-[rgba(0,200,83,0.08)] blur-[80px] top-[25%] left-[15%] pointer-events-none" />
      <div className="fixed w-[160px] h-[160px] rounded-full bg-[rgba(251,191,36,0.06)] blur-[80px] bottom-[20%] right-[10%] pointer-events-none" />

      <div className="w-full max-w-[380px] text-center">
        {/* Logo */}
        <img
          src={LOGO_URL}
          alt="Be Rich"
          className="w-[80px] h-[80px] mx-auto mb-4 object-contain"
          style={{ filter: 'drop-shadow(0 4px 20px rgba(251,191,36,0.2))' }}
          onError={(e) => {
            const t = e.target as HTMLImageElement;
            const p = t.parentElement;
            if (p) {
              const div = document.createElement('div');
              div.className = 'bg-gradient-to-br from-[#00E676] to-[#00C853] rounded-[22px] flex items-center justify-center text-white font-black w-[80px] h-[80px] mx-auto mb-4';
              div.textContent = 'BR';
              p.replaceChild(div, t);
            }
          }}
        />
        <h1 className="text-[1.6rem] font-black mb-1 bg-gradient-to-r from-[#FCD34D] via-[#FBBF24] to-[#F59E0B] bg-[length:200%_auto] text-transparent bg-clip-text tracking-[2px]">
          BE RICH
        </h1>

        {!sent ? (
          <>
            <div className="w-14 h-14 mx-auto rounded-full bg-[rgba(251,191,36,0.1)] flex items-center justify-center mb-4 mt-6">
              <i className="fas fa-lock text-[#FBBF24] text-[1.2rem]"></i>
            </div>
            <h2 className="text-[1.1rem] font-bold text-white mb-2">Mot de passe oublié ?</h2>
            <p className="text-[rgba(255,255,255,0.4)] text-[0.78rem] mb-6 leading-relaxed">
              Entrez votre adresse email et nous vous enverrons un lien pour réinitialiser votre mot de passe.
            </p>

            <form onSubmit={handleSubmit} className="text-left">
              <div className="mb-4 w-full">
                <label className="block mb-1.5 text-[0.75rem] font-semibold text-[rgba(255,255,255,0.35)]">
                  Adresse email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  placeholder="votre@email.com"
                  className="w-full py-3 px-4 bg-[rgba(255,255,255,0.05)] border-[1.5px] border-[rgba(255,255,255,0.08)] rounded-xl text-[0.88rem] outline-none transition-all font-[Inter] text-white placeholder:text-[rgba(255,255,255,0.2)] focus:bg-[rgba(255,255,255,0.08)] focus:border-[#FBBF24] focus:shadow-[0_0_0_3px_rgba(251,191,36,0.08)]"
                />
              </div>

              {error && (
                <div className="mb-4 p-3 bg-[rgba(239,68,68,0.1)] border border-[rgba(239,68,68,0.2)] rounded-xl">
                  <p className="text-[0.78rem] text-[#F87171] font-medium">{error}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FCD34D] to-[#FBBF24] text-[#78350F] font-bold text-[0.88rem] border-none cursor-pointer shadow-[0_4px_20px_rgba(251,191,36,0.2)] font-[Inter] transition-transform active:scale-[0.97] disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <div className="w-4 h-4 border-2 border-[rgba(120,53,15,0.3)] border-t-[#78350F] rounded-full" style={{ animation: 'spin 0.6s linear infinite' }} />
                ) : (
                  <>
                    <i className="fas fa-paper-plane"></i> Envoyer le lien
                  </>
                )}
              </button>
            </form>

            <div className="mt-6">
              <a
                href="/"
                className="text-[0.78rem] text-[rgba(255,255,255,0.4)] hover:text-[#FBBF24] transition-colors inline-flex items-center gap-1.5"
              >
                <i className="fas fa-arrow-left text-[0.7rem]"></i> Retour à la connexion
              </a>
            </div>
          </>
        ) : (
          <>
            <div className="w-16 h-16 mx-auto rounded-full bg-[rgba(0,200,83,0.1)] flex items-center justify-center mb-4 mt-6">
              <i className="fas fa-check-circle text-[#00E676] text-[1.6rem]"></i>
            </div>
            <h2 className="text-[1.1rem] font-bold text-white mb-2">Email envoyé !</h2>
            <p className="text-[rgba(255,255,255,0.4)] text-[0.78rem] mb-6 leading-relaxed">
              Si un compte existe avec l&apos;adresse <strong className="text-[rgba(255,255,255,0.7)]">{email}</strong>, vous recevrez un lien de réinitialisation dans quelques instants.
            </p>

            <div className="p-4 bg-[rgba(255,255,255,0.03)] rounded-xl border border-[rgba(255,255,255,0.05)] mb-6 text-left">
              <div className="flex items-start gap-3">
                <i className="fas fa-info-circle text-[#FBBF24] mt-0.5 shrink-0 text-[0.85rem]"></i>
                <div>
                  <h4 className="text-[0.78rem] font-bold text-[rgba(255,255,255,0.6)] mb-1">Vérifiez votre boîte mail</h4>
                  <p className="text-[0.7rem] text-[rgba(255,255,255,0.3)] leading-relaxed">
                    Le lien de réinitialisation est valable pendant 1 heure. N&apos;oubliez pas de vérifier vos spams.
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={() => { setSent(false); setEmail(''); }}
              className="w-full py-3 rounded-xl border-[1.5px] border-[rgba(255,255,255,0.08)] bg-transparent text-[rgba(255,255,255,0.5)] font-semibold text-[0.82rem] cursor-pointer font-[Inter] transition-transform active:scale-95 mb-3"
            >
              <i className="fas fa-redo mr-1.5 text-[0.7rem]"></i> Renvoyer un email
            </button>

            <a
              href="/"
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#00E676] to-[#00C853] text-white font-semibold text-[0.88rem] border-none cursor-pointer shadow-[0_4px_20px_rgba(0,200,83,0.2)] font-[Inter] transition-transform active:scale-[0.97] flex items-center justify-center gap-2 no-underline"
            >
              <i className="fas fa-arrow-left"></i> Retour à la connexion
            </a>
          </>
        )}
      </div>

      <style jsx>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
